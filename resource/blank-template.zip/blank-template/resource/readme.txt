place resources in here

examples:
- css
- js
