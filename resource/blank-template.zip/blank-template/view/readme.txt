place views in here

examples:
- index.html
- products.html
