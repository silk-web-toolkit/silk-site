place metadata in here

examples:
- robots.txt
- favicon.ico
- sitemap.xml
